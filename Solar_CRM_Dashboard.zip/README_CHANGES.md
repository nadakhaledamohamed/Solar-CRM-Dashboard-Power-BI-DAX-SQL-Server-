# Solar CRM Dashboard (Power BI PBIP)

Built on SolarCRM_DW (schema dw) using the charcoal + gold theme and the three template pages.

Pages
- Overview: Contract value, leads, avg contract value, lead-to-contract rate, cancellation rate, contracts signed; trends by month, quarter/region, product.
- Operations: speed to first contact, install backlog, activities, connect rate, days sign-to-install, cost per contract; installations, activities by channel, lead share by region.
- Trends & Alerts: 5 alert cards (value, status, limit from vw_LatestAlerts) + monthly trend lines from vw_KPI_Monthly with the alert limit as a dashed red line.

Setup
- Open Solar_CRM_Dashboard.pbip. Server is "localhost", database "SolarCRM_DW": change via Transform data > Data source settings.
- Date table is cut at the end of the current year (no empty future years in the Year slicer).
- Marketing spend / cost per contract is blank when a Region or Product filter is active (spend has no region).
- Validated against Power BI JSON schemas and an integrity check; not opened in Power BI Desktop here.
